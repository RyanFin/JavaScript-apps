
<!---

This README is automatically generated from the comments in these files:
iron-menu-behavior.html  iron-menubar-behavior.html

Edit those files, and our readme bot will duplicate them over here!
Edit this file, and the bot will squash your changes :)

-->

[![Build Status](https://travis-ci.org/PolymerElements/iron-menu-behavior.svg?branch=master)](https://travis-ci.org/PolymerElements/iron-menu-behavior)

_[Demo and API Docs](https://elements.polymer-project.org/elements/iron-menu-behavior)_


##Polymer.IronMenuBehavior


`Polymer.IronMenuBehavior` implements accessible menu behavior.



##Polymer.IronMenubarBehavior


`Polymer.IronMenubarBehavior` implements accessible menubar behavior.


